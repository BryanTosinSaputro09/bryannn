/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/** 
 *
 * @author Asus
 */
public class tugasFungsi {
    public static void main(String[] args) {
         int menu;
        do{Scanner sc = new Scanner(System.in);
            System.out.println("");
            System.out.println("ROYALE GARDEN");
            System.out.println("Silahkan Pilih Menu :");
            System.out.println("No.1 Menampilkan Stock Bunga");
            System.out.println("No.2 Menampilkan seluruh stock bunga di seluruh cabang");
            System.out.println("No.3 Keluar");
            System.out.println("Pilihan Menu Anda(1 , 2 , 3)");
            menu = sc.nextInt();
            switch(menu){
                case 1 : {
                    System.out.println("Menu 1. Menampilkan Stock Bunga");
                    menampilkanStockBunga();
                }break;
                case 2 : {
                    System.out.println("Menu 2. Menampilkan seluruh stock bunga di seluruh cabang");
                    menampilkanSeluruhStock();
                }break;
                case 3 : {
                    System.out.println("Menu 3. Keluar");
                }break;
            }
        }while(menu > 0 && menu <= 3);

        }

    private static void menampilkanStockBunga() {
        int[][] bunga = {{10, 5, 15, 7},
                         {6, 11, 9, 12},
                         {2, 10, 10, 5},
                         {5, 7, 12, 9}};
        System.out.println("\t\t"+" Algonema "+"\t\t"+"Keladi"+"\t\t"+"Alocasia"+"\t"+"Mawar");
        System.out.println("RoyalGarden1" + "\t\t" + bunga[0][0] + "\t\t" + bunga[0][1] + "\t\t" + bunga[0][2] + "\t\t" + bunga[0][3] );
        System.out.println("RoyalGarden2" + "\t\t" + bunga[1][0] + "\t\t" + bunga[1][1] + "\t\t" + bunga[1][2] + "\t\t" +bunga[1][3]);
        System.out.println("RoyalGarden3" + "\t\t" + bunga[2][0] + "\t\t" + bunga[2][1] + "\t\t" + bunga[2][2] + "\t\t" + bunga[2][3]);
        System.out.println("RoyalGarden4" + "\t\t" + bunga[3][0] + "\t\t" + bunga[3][1] + "\t\t" + bunga[3][2] + "\t\t" + bunga[3][3]);
        System.out.println("");
    }
    
        private static void menampilkanSeluruhStock() {
                int[][] bunga = {
                {10, 5, 15, 7},
                {6, 11, 9, 12},
                {2, 10, 10, 5},
                {5, 7, 12, 9}
        };
        int algonema = 0, keladi = 0, alocasia = 0, mawar = 0, pendapatan, totalBunga;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (j == 0) {
                    algonema += bunga[i][j];
                } else if (j == 1) {
                    keladi += bunga[i][j];
                } else if (j == 2) {
                    alocasia += bunga[i][j];
                } else {
                    mawar += bunga[i][j];
                }
            }
        }

        totalBunga = (algonema + keladi + alocasia + mawar);

        System.out.println("Jumlah Bunga di Seluruh Cabang: " + totalBunga);
        System.out.println("Jumlah Bunga Algonema   : " + algonema);
        System.out.println("Jumlah Bunga Keladi     : " + keladi);
        System.out.println("Jumlah Bunga Alocasia   : " + alocasia);
        System.out.println("Jumlah Bunga Mawar      : " + mawar);
    }
}
