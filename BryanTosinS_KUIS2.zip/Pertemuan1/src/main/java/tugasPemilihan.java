/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author Asus
 */
public class tugasPemilihan{
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        String nama , nim ;
        char grade ;
        final double n_tugas , n_uts , n_uas , n_akhir;
        System.out.println("===== Program Menghitung Nilai Akhir =====\n");
        System.out.print("Masukan nama : ");
        nama = sc.nextLine();
        System.out.print("Masukan NIM : ");
        nim = sc.nextLine();
        System.out.print("Nilai nilai tugas : ");
        n_tugas = sc.nextInt();
        System.out.print("Nilai nilai uts : ");
        n_uts = sc.nextInt();
        System.out.print("Nilai nilai uas : ");
        n_uas = sc.nextInt();
        n_akhir = (0.15 * n_tugas + 0.5 *  n_uts + 0.35 * n_uas);
        if (n_akhir >= 85 && n_akhir <=100){
            grade = 'A';
        }else if (n_akhir > 75 && n_akhir < 85){
            grade = 'B';
        }else if (n_akhir > 65 && n_akhir < 75){
            grade = 'C';
        }else if (n_akhir > 50 && n_akhir < 65){
            grade = 'D';
        }else {
            grade = 'E';
        }if (grade == 'A' || grade == 'B' || grade == 'C'){
            System.out.println("\n"+nama+" dengan NIM "+nim+" memiliki nilai akhir "+n_akhir+" = ("+grade+")"+""
                    + "\n dan dinyatakan Lulus");
        }else {System.out.println("\n"+nama+" dengan NIM "+nim+" memiliki nilai akhir "+n_akhir+" = ("+grade+")"+""
                    + "\n dan dinyatakan Tidak Lulus");
        }  
    }
}
