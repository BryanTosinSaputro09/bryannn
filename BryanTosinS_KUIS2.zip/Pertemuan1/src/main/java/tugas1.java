/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Asus
 */

public class tugas1 {
    public static void main(String[] args) {
        int ani = 4, budi = 15, bina = 6, cita = 11;
        double totalPendapatan;
        System.out.println("Harga per Pelanggan : ");
        System.out.println("Ani  Rp " +(4*4500));
        System.out.println("Budi Rp " +(15*4500*0.05));
        System.out.println("Bina Rp " +(6*4500));
        System.out.println("Cita Rp " +(11*4500*0.05));
        totalPendapatan = ((4*4500)+(15*4500*0.05)+(6*4500)+(11*4500*0.05));
        System.out.println("Total Pendapatan Smile Laundry Pada hari itu Adalah Rp. " +totalPendapatan);
    }
}
